The graph data sets are donated by a number of different authors and organizations and in many cases have provided the citation information that should be used upon request. 

For acknowledgment of data from network repository (in published materials), the following is recommended:

@misc{graphrepository2013,
   title={Network Repository},
   author={Ryan Rossi and Nesreen Ahmed},
   url={http://networkrepository.com},
   institution={Purdue University},
   year={2013}
}